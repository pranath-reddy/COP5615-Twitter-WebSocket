-module({{modid}}_tests).
-include_lib("eunit/include/eunit.hrl").


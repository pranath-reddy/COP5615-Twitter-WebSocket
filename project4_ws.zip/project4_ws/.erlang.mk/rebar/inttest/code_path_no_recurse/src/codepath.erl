-module(codepath).

-export([codepath/0]).

codepath() ->
    foodep:foodep().

-module({{module}}).

-include_lib("b/include/b.hrl").

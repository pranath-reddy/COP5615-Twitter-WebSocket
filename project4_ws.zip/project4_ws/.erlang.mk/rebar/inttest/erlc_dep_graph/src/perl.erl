%% -*- mode: erlang;erlang-indent-level: 4;indent-tabs-mode: nil -*-
%% ex: ts=4 sw=4 ft=erlang et
-module(perl).

-export(['$_'/0]).

-compile({parse_transform, lisp}).

'$_'() ->
	anything.

%% -*- mode: erlang;erlang-indent-level: 4;indent-tabs-mode: nil -*-
%% ex: ts=4 sw=4 ft=erlang et
-module(pascal).

-export([parse_transform/2]).

parse_transform(Forms, _Options) ->
    Forms.

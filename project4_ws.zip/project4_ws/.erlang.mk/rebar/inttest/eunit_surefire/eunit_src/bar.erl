-module(bar).

-include_lib("eunit/include/eunit.hrl").

bar_test() ->
    ?assert(true).
